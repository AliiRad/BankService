package ir.bankservice.model.entity;

import com.google.gson.Gson;
import ir.bankservice.model.entity.enums.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Entity(name = "employeeEntity")
@Table(name = "employee_tbl")

@NamedQueries({
        @NamedQuery(name = "employee.findByNameAndFamily" , query = "select oo from employeeEntity oo where oo.username=:name and oo.password=:family and oo.deleted=false"),
        @NamedQuery(name = "employee.showAll",query = "select emp from employeeEntity emp")
})

public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "first_name", columnDefinition = "NVARCHAR2(20)",nullable = false,unique = true)
    private String username;

    @Column(name = "last_name", columnDefinition = "NVARCHAR2(20)",nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    private Role role;

    private boolean deleted;

    public Employee(String username, String password, Role role, boolean deleted) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
