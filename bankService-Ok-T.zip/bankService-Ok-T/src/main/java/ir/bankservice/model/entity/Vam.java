package ir.bankservice.model.entity;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder


@Entity(name = "vamEntity")
@Table(name = "vam_tbl")
public class Vam {

    @Id
    @SequenceGenerator(name = "vamSeq",sequenceName = "vam_seq",allocationSize = 1,initialValue = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE ,generator = "vamSeq")
    private long id;

    private String cc_number;

    private long amountReq ;

    @JsonProperty("تاریخ درخواست وام")
    @NotNull(message = "تاریخ نمیتواند خالی باشد")
    private LocalDateTime req_date;


    @ManyToOne
    @JoinColumn(name = "user_id")
    private User zamen;

    public Vam(String cc_number, long amountReq, LocalDateTime req_Date) {
        this.cc_number = cc_number;
        amountReq = amountReq;
        this.req_date = req_Date;
    }

    public Vam(String cc_number, long amountReq, LocalDateTime req_date, User user) {
        this.cc_number = cc_number;
        this.amountReq = amountReq;
        this.req_date = req_date;
        this.zamen = user;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
