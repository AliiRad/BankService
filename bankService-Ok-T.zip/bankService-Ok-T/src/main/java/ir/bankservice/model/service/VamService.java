package ir.bankservice.model.service;

import ir.bankservice.model.entity.Vam;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

public class VamService implements ServiceImpl<Vam,Long> {
    private static VamService vamService = new VamService();

    private VamService() {
    }

    public static VamService getVamService() {
        return vamService;
    }

    @Override
    public Vam insert(Vam vam) {
        try(CrudRepository<Vam,Long> vamDA = new CrudRepository<>()){
            return vamDA.insert(vam);
        }
    }

    @Override
    public Vam update(Vam vam) {
        try(CrudRepository<Vam,Long> vamDA = new CrudRepository<>()){
            return vamDA.update(vam);
        }
    }

    @Override
    public Vam delete(Long id) {
        try(CrudRepository<Vam,Long> vamDA = new CrudRepository<>()){
            return vamDA.delete(Vam.class,id);
        }
    }

    @Override
    public Vam selectById(Long id) {
        try(CrudRepository<Vam,Long> vamDA = new CrudRepository<>()){
            return vamDA.selectById(Vam.class,id);
        }
    }

    @Override
    public List<Vam> selectAll() {
        try(CrudRepository<Vam,Long> vamDA = new CrudRepository<>()){
            return vamDA.selectAll(Vam.class);
        }
    }

//    public static void main(String[] args) {
//        Vam vam = new Vam("5894631578120554",1000L, LocalDateTime.now());
//        System.out.println(VamService.getVamService().insert(vam));
//    }
}
