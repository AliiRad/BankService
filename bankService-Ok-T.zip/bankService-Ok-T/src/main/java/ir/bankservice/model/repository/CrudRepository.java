package ir.bankservice.model.repository;

import ir.bankservice.model.entity.User;
import ir.bankservice.model.utils.JPA;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CrudRepository<T, I> implements AutoCloseable {

    public T insert(T t) {
        EntityManager entityManager = JPA.getJpa().getEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.persist(t);
        entityTransaction.commit();
        return t;
    }

    public T update(T t) {
        EntityManager entityManager = JPA.getJpa().getEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.merge(t);
        entityTransaction.commit();
        return t;
    }

    public T delete(Class<T> tClass, I id) {
        EntityManager entityManager = JPA.getJpa().getEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        T t = entityManager.find(tClass, id);
        entityManager.remove(t);
        entityTransaction.commit();
        return t;
    }

    EntityManager entityManager = JPA.getJpa().getEntityManager();

    public T selectById(Class<T> tClass, I id) {
        entityManager = JPA.getJpa().getEntityManager();
        T entity = entityManager.find(tClass, id);
        return entity;
    }


    public List<T> selectAll(Class<T> tClass) {
        entityManager = JPA.getJpa().getEntityManager();
        String sql = "select entity from " + tClass.getAnnotation(Entity.class).name() + " entity ";
        Query query =
                entityManager
                        .createQuery(sql);
        List<T> tList = query.getResultList();
        return tList;
    }

    public T executeQuery(String queryName, Map<String, Object> paramMap) {
        entityManager = JPA.getJpa().getEntityManager();
        Query query =
                entityManager
                        .createNamedQuery(queryName);
        if (paramMap != null) {
            for (String key : paramMap.keySet()) {
                query.setParameter(key, paramMap.get(key));
            }
        }

        T result = (T) query.getSingleResult();
        return (result.toString().length() > 0 ? result : null);
    }

    public List<T> executeQueryByList(String queryName, Map<String, Object> paramMap) {
        entityManager = JPA.getJpa().getEntityManager();
        Query query =
                entityManager
                        .createNamedQuery(queryName);
        if (paramMap != null) {
            for (String key : paramMap.keySet()) {
                query.setParameter(key, paramMap.get(key));
           }
        }

            List<T> tList = query.getResultList();
            return (tList.toString().length() > 0 ? tList : null);
    }

    @Override
    public void close() {
        entityManager.close();
    }
}
