package ir.bankservice.model.entity;


import ir.bankservice.model.entity.enums.Operations;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Getter // data :using @data for Jpa entities is not recommended
@Setter // data :using @data for Jpa entities is not recommended
@Builder

@Entity(name = "transaction_Entity")
@Table(name = "transaction_tbl")
public class Transaction {
    @Id
    @SequenceGenerator(name = "transactionSeq",sequenceName = "tr_seq",initialValue = 1,allocationSize = 1)// TODO: tr_seq database is transaction_seq
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "transactionSeq")
    private Long id;

    @NonNull
    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "VARCHAR2(20)")
    private Operations operations;

    @NonNull
    private String data;

    @NonNull
    private LocalDateTime tr_date;

    @OneToOne
    private Card card;

    public Transaction(@NonNull Operations operations, @NonNull String data, @NonNull LocalDateTime tr_date, Card card) {
        this.operations = operations;
        this.data = data;
        this.tr_date = tr_date;
        this.card = card;
    }
}
