package ir.bankservice.model.entity.enums;

public enum Role {
    Admin,
    Employee
}
