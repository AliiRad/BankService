package ir.bankservice.model.service;

import ir.bankservice.model.entity.Employee;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeService implements ServiceImpl<Employee, Long> {

    private static EmployeeService employeeService = new EmployeeService();

    private EmployeeService() {
    }

    public static EmployeeService getEmployeeService() {
        return employeeService;
    }

    @Override
    public Employee insert(Employee employee) {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.insert(employee);
        }
    }

    @Override
    public Employee update(Employee employee) {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.update(employee);
        }
    }

    @Override
    public Employee selectById(Long id) {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.selectById(Employee.class, id);
        }
    }

    @Override
    public Employee delete(Long id) {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            Employee employee = EmployeeService.getEmployeeService().selectById(id);
            employee.setDeleted(true);
            return employeeDA.update(employee);
        }
    }


    public Employee selectByNameAndFamily(String name ,String family){
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            Map<String,Object> params = new HashMap<>();
            params.put("name",name);
            params.put("family",family);
            return employeeDA.executeQuery("employee.findByNameAndFamily", params);
        }
    }



    public List<Employee> selectAllDeleted() throws Exception {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.executeQueryByList("employee.selectAllDeleted", null);
        }
    }


    public List<Employee> selectAllActive() throws Exception {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.executeQueryByList("employee.selectAllActive", null);
        }
    }

    public List<Employee> showAllEmployee(){
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            Map<String,Object> params = new HashMap<>();
            return employeeDA.executeQueryByList("employee.showAll", null);
        }
    }

    @Override
    public List<Employee> selectAll() {
        try (CrudRepository<Employee, Long> employeeDA = new CrudRepository<>()) {
            return employeeDA.selectAll(Employee.class);
        }
    }

//    public static void main(String[] args) throws Exception {
//        Employee employee = new Employee("ali","rad", Role.Employee,false);
//        System.out.println(EmployeeService.getEmployeeService().delete(1L));
//        System.out.println(EmployeeService.getEmployeeService().selectAllActive());
//    }
}
