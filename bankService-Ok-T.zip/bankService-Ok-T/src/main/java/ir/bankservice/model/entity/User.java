package ir.bankservice.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.validator.constraints.Length;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder


@Entity(name = "userEntity")
@Table(name = "user_tbl")
@NamedQueries({

        @NamedQuery(name = "user.findByUsername", query = "select user from userEntity user where user.username=:username"),//for Zamen in VamService
        @NamedQuery(name = "user.findByUserAndPass", query = "select user from userEntity user where user.username=:username and user.password=:password"),// for Login form and auth
        @NamedQuery(name = "user.updateByUsernameAndPassword", query = "update userEntity user set user.username=:username , user.password=:password where user.id=:id"), // Debug...
        @NamedQuery(name = "user.selectAllDeleted", query = "select user from userEntity user where user.deleted=true "),//for Admin Page
        @NamedQuery(name = "user.selectAllActive", query = "select user from userEntity user where user.deleted=false "),// for Admin Page
        @NamedQuery(name = "user.selectActivateUser", query = "select user from userEntity user where user.username=:username and user.password=:password and user.AdminReq=true"),//  Those whom the admin has accepted
        @NamedQuery(name = "user.falseReq" , query = "select user from userEntity user where user.AdminReq=false"),//   Those whom the admin has not accepted


})
public class User {

    @Id
    @SequenceGenerator(name = "userSeq", sequenceName = "user_seq", initialValue = 1, allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userSeq")
    private long id;


    @Column(columnDefinition = "NVARCHAR2(20)", unique = true)
    @JsonProperty("نام کاربری")
    @NotBlank(message = "نام کاربری نمیتواند خالی باشد")
    @Length(min = 3, max = 20, message = "طول نام کاربری صحیح نیست")
    private String username;


    @Column(columnDefinition = "NVARCHAR2(20)")
    @JsonProperty("کلمه عبور")
    @NotBlank(message = "کلمه عبور نمیتواند خالی باشد")
    @Length(min = 3, max = 20, message = "طول کلمه عبور صحیح نیست")
    private String password;


    @OneToOne(cascade = CascadeType.ALL)
    private Person person;

    @JsonIgnore
    private boolean deleted;

    private boolean AdminReq;




    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Update Service in Employee Page (EmployeeController)
    public User(long id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;

    }


//    Register User


    public User(String username, String password,  Person person, boolean deleted, boolean adminReq) {
        this.username = username;
        this.password = password;
        this.person = person;
        this.deleted = deleted;
        AdminReq = adminReq;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
