package ir.bankservice.model.service;

import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CardService implements ServiceImpl<Card,Long> {
    private static CardService cardService = new CardService();

    private CardService() {
    }

    public static CardService getCardService() {
        return cardService;
    }
    
    public Card insert(Card card) {
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            return cardDA.insert(card);
        }
    }

    public Card update(Card card) {
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            return cardDA.update(card);
        }
    }

    public Card delete(Long id) {
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            return cardDA.delete(Card.class,id);
        }
    }

    @Override
    public Card selectById(Long id) {
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            return cardDA.selectById(Card.class,id);
        }
    }

//   New
    public Card selectByCcNumber(String ccNumber) throws Exception{
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            Map<String, Object> params= new HashMap<>();
            params.put("ccNumber",ccNumber);
            return cardDA.executeQuery("card.findBycNumber", params);
        }
    }

    public Card selectByPassword(short password) throws Exception{
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            Map<String, Object> params= new HashMap<>();
            params.put("password",password);
            return cardDA.executeQuery("card.selectByPassword", params);
        }
    }

    public Card selectByCcNumberAndPassword(String ccNumber,short password) throws Exception{
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            Map<String, Object> params= new HashMap<>();
            params.put("cc_number",ccNumber);
            params.put("password",password);
            return cardDA.executeQuery("card.selectByCcNumberAndPassword", params);
        }
    }

    public List<Card> selectAll(){
        try(CrudRepository<Card,Long> cardDA = new CrudRepository<>()) {
            return cardDA.selectAll(Card.class);
        }
    }

//    public static void main(String[] args) {
//        Card card = new Card("5894631578120883","1234",1000000000L, LocalDateTime.now());
//        System.out.println(CardService.getCardService().insert(card));
//
//    }
}
