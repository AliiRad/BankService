package ir.bankservice.model.service;

import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Person;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService implements ServiceImpl<User,Long> {

    private static UserService userService = new UserService();

    private UserService() {
    }

    public static UserService getUserService() {
        return userService;
    }

    public User insert(User user) {
        // todo : if user is not saved save it , else error
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            return userDA.insert(user);
        }
    }

    public User update(User user)  {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            return userDA.update(user);
        }
    }


    public User delete(Long id) {
        try (CrudRepository<User, Long> userDA = new CrudRepository<>()) {
            User user = UserService.getUserService().selectById(id);
            user.setDeleted(true);
            return userDA.update(user);
        }
    }

    public List<User> selectByFalseReq() {
        try (CrudRepository<User, Long> userDA = new CrudRepository<>()) {
            return userDA.executeQueryByList("user.falseReq",null);
        }
    }

    public User falseReqValidator(String username,String password) {
        try (CrudRepository<User, Long> userDA = new CrudRepository<>()) {
            User user = new User(username,password);
            return userDA.executeQuery("user.falseReqValidator",null);
        }
    }

    public User activateTheUser(Long id) {
        try (CrudRepository<User, Long> userDA = new CrudRepository<>()) {
            User user = UserService.getUserService().selectById(id);
            user.setAdminReq(true);
            return userDA.update(user);
        }
    }



    // Vam Service (Zamen is valid)
    public User selectByUsername(String username) throws Exception{
            try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
                Map<String, Object> param = new HashMap<>();
                param.put("username",username);
                return userDA.executeQuery("user.findByUsername",param);
            }
    }


    // Login
    public User selectByUsernameAndPass(String username,String password) throws Exception{
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            Map<String, Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            return userDA.executeQuery("user.findByUserAndPass",param);
        }
    }

    public User updateByUsernameAndPassword(long id,String username,String password) throws Exception{
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            Map<String, Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            param.put("id",id);
            return userDA.executeQuery("user.updateByUsernameAndPassword",param);
        }
    }

    public List<Person> selectAllDeleted() throws Exception {
        try (CrudRepository<Person, Long> userDA = new CrudRepository<>()) {
            return userDA.executeQueryByList("user.selectAllDeleted", null);
        }
    }


    public List<Person> selectAllActive() throws Exception {
        try (CrudRepository<Person, Long> userDA = new CrudRepository<>()) {
            return userDA.executeQueryByList("user.selectAllActive", null);
        }
    }

    public User selectActivateUser(String username,String password) throws Exception {
        try (CrudRepository<User, Long> userDA = new CrudRepository<>()) {
            Map<String,Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            return userDA.executeQuery("user.selectActivateUser", param);
        }
    }

    // Check For Service (IF CC is Yours-->Continue)
    public User getCcNumber(String username, String password) throws Exception{
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            Map<String, Object> param = new HashMap<>();
            param.put("username",username);
            param.put("password",password);
            return userDA.executeQuery("user.getCcNumber",param);
        }
    }

    public User selectById(Long id){
        try (CrudRepository<User,Long> userDA = new CrudRepository<>()){
            return userDA.selectById(User.class , id);
        }
    }

    public List<User> selectAll()  {
        try(CrudRepository<User,Long> userDA = new CrudRepository<>()) {
            return userDA.selectAll(User.class);
        }
    }

//    public static void main(String[] args) throws Exception {
//        User user = new User("ali","ali123");
//        UserService.getUserService().insert(user);
//    }
}
