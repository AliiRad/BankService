package ir.bankservice.model.service;

import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Person;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

public class PersonService implements ServiceImpl<Person, Long> {
    private static PersonService personService = new PersonService();

    private PersonService() {
    }

    public static PersonService getPersonService() {
        return personService;
    }

    @Override
    public Person insert(Person person) {
        try (CrudRepository<Person, Long> personDA = new CrudRepository<>()) {
            return personDA.insert(person);
        }
    }

    @Override
    public Person update(Person person) {
        try (CrudRepository<Person, Long> personDA = new CrudRepository<>()) {
            return personDA.update(person);
        }
    }

    @Override
    public Person delete(Long id) {
        try (CrudRepository<Person,Long> personDA = new CrudRepository<>()) {
            return personDA.delete(Person.class, id);
        }
    }

    @Override
    public Person selectById(Long id) {
        try (CrudRepository<Person, Long> personDA = new CrudRepository<>()) {
            return personDA.selectById(Person.class, id);
        }
    }


    @Override
    public List<Person> selectAll() {
        try (CrudRepository<Person, Long> personDA = new CrudRepository<>()) {
            return personDA.selectAll(Person.class);
        }
    }

//    public static void main(String[] args) throws Exception {
//        Person person = new Person("ali","rad","0151451771","fatherName",new User("ali","ali123"),new Card("5894631578120883","1234",1000L, LocalDateTime.now()));
//        PersonService.getPersonService().save(person);
//    }

}
