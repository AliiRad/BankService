package ir.bankservice.model.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.*;
import org.hibernate.validator.constraints.Length;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Entity(name = "personEntity")
@Table(name = "person_tbl")

public class Person {
    @Id
    @SequenceGenerator(name = "personSeq",sequenceName = "person_seq",initialValue = 1,allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "personSeq")
    @Max(500)
    private long id;

    @Column(columnDefinition = "NVARCHAR2(20)")
    @JsonProperty("نام")
    @NotBlank(message = "نام نمیتواند خالی باشد")
    @Length(min = 3, max = 20,message = "طول نام صحیح نیست")
    @Pattern(regexp = "[ا-ی\\s]*", message = "نام صحیح وارد نشده است")
    private String name;

    @Column(columnDefinition = "NVARCHAR2(20)")
    @Pattern(regexp = "[ا-ی\\s]*", message = "نام خانوادگی صحیح وارد نشده است")
    @Length(min = 3, max = 20,message = "طول نام صحیح نیست")
    @NotBlank(message = "نام خانوادگی نمیتواند خالی باشد")
    @JsonProperty("نام خانوادگی")
    private String family;

    @Column(columnDefinition = "CHAR(16)",unique = true)
    @Length(min = 10,max = 10,message = "کد ملی باید 16 رقم باشد")
    @JsonProperty("کد ملی")
    @NotBlank(message = "کد ملی نمیتواند خالی باشد")
    private String nc_number;

    @Column(columnDefinition = "NVARCHAR2(20)")
    @Pattern(regexp = "[ا-ی\\s]*", message = "نام پدر صحیح وارد نشده است")
    @Length(min = 3, max = 20,message = "طول نام پدر صحیح نیست")
    @NotBlank(message = "نام پدر نمیتواند خالی باشد")
    @JsonProperty("نام پدر")
    private String father_name;

//    @OneToOne
//    private User user;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "card_id")
    private Card card;




    public Person(String name, String family, String nc_number, String father_name, Card card) {
        this.name = name;
        this.family = family;
        this.nc_number = nc_number;
        this.father_name = father_name;
//        this.user = user;
        this.card = card;
    }



    @Override
    public String toString() {
        return new Gson().toJson(this);
    }


}
