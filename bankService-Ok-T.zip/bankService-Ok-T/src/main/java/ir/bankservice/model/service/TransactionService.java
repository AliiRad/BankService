package ir.bankservice.model.service;

import ir.bankservice.model.entity.Transaction;
import ir.bankservice.model.repository.CrudRepository;
import ir.bankservice.model.service.impl.ServiceImpl;

import java.util.List;

public class TransactionService implements ServiceImpl<Transaction,Long> {
    private static TransactionService transactionService = new TransactionService();

    private TransactionService() {
    }

    public static TransactionService getTransactionService() {
        return transactionService;
    }



    @Override
    public Transaction insert(Transaction transaction) {
        try (CrudRepository<Transaction, Long> transactionDa = new CrudRepository<>()) {
            return transactionDa.insert(transaction);
        }
    }

    @Override
    public Transaction update(Transaction transaction) {
        try (CrudRepository<Transaction, Long> transactionDa = new CrudRepository<>()) {
            return transactionDa.update(transaction);
        }
    }

    @Override
    public Transaction delete(Long id) {
        try (CrudRepository<Transaction, Long> transactionDa = new CrudRepository<>()) {
            return transactionDa.delete(Transaction.class, id);
        }
    }

    @Override
    public Transaction selectById(Long id) {
        try (CrudRepository<Transaction, Long> transactionDa = new CrudRepository<>()) {
            return transactionDa.selectById(Transaction.class ,id);
        }
    }



    @Override
    public List<Transaction> selectAll() {
        try (CrudRepository<Transaction, Long> transactionDa = new CrudRepository<>()) {
            return transactionDa.selectAll(Transaction.class);
        }
    }
}

