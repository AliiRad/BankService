package ir.bankservice.model.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.Gson;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder

@Entity(name = "cardEntity")
@Table(name = "card_tbl")
@NamedQueries({
        @NamedQuery(name = "card.findBycNumber", query = "select oo from cardEntity oo where oo.cc_number=:ccNumber"),
        @NamedQuery(name = "card.selectByPassword", query = "select oo from cardEntity oo where oo.password=:password"),
        @NamedQuery(name = "card.selectByCcNumberAndPassword", query = "select oo from cardEntity oo where oo.cc_number=:cc_number and oo.password=:password")
})
public class Card {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(columnDefinition = "char(16)", unique = true)
    @JsonProperty("شماره کارت")
    @NotBlank(message = "شماره کارت نمیتواند خالی باشد")
    private String cc_number;



    @Column(columnDefinition = "NUMBER(4)")
    private short password;

    @Column(columnDefinition = "NVARCHAR2(4)")
    @JsonProperty("CVV2")
    @NotBlank(message = "CVV2 نمیتواند خالی باشد")
    private String cvv2;

    @JsonProperty("موجودی")
    @Column(length = 20)
    private long credit;


    @JsonProperty("تاریخ افتتاح حساب")
    @NotNull(message = "تاریخ نمیتواند خالی باشد")
    private LocalDateTime create_date;


    public Card(String cc_number, short password, String cvv2, long credit) {
        this.cc_number = cc_number;
        this.password = password;
        this.cvv2 = cvv2;
        this.credit = credit;
    }

    @PrePersist
    private void setDateTime() {
        create_date = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}
