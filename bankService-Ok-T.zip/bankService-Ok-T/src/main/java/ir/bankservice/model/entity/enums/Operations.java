package ir.bankservice.model.entity.enums;

public enum Operations {
    variz,
    bardasht,
    reqVam,
    mojodi
}
