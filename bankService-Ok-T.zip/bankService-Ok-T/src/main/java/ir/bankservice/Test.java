package ir.bankservice;

import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Person;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.PersonService;
import ir.bankservice.model.service.UserService;

import java.time.LocalDateTime;

public class Test {
    public static void main(String[] args) {
        Card card = new Card("5894631578120883",(short) 2007, "2001",10000000L);
        Person person = new Person("علی","راد","0151451771","فرامرز",card);
        User user = new User("ali","ali123",person,false,false);
        System.out.println(UserService.getUserService().insert(user));

    }
}
