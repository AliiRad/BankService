package ir.bankservice.controller.servlet.personal.admin;

import ir.bankservice.controller.CardController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet(urlPatterns = "/addCard.do")
public class AddCard extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        String cc_number = req.getParameter("cc_number");
//        short cardPassword = Short.parseShort(req.getParameter("cardPass"));
//        String cvv2 = req.getParameter("cvv2");
//        Long credit = Long.valueOf(req.getParameter("credit"));
//
//        if (cc_number != null && cvv2 != null && credit.toString().length() > 7) {
//            CardController cardController = new CardController();
//            if (cardController.addCard(cc_number, cardPassword, cvv2, credit, LocalDateTime.now()).equals("CardAdded")) {
//                resp.sendRedirect("personal/admin/service/addCard.jsp");
//            } else {
//                resp.getWriter().write(cardController.addCard(cc_number, cardPassword, cvv2, credit, LocalDateTime.now()));
//            }
//        } else {
//            resp.getWriter().write("null value detected");
//        }
    }
}
