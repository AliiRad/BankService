package ir.bankservice.controller.servlet.personal.admin;

import ir.bankservice.controller.UserController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/admin.Du")  // Du : Delete User
public class DuServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        long id = Long.parseLong(req.getParameter("user_id"));
        UserController userController = new UserController();
        if (userController.delete(id).equals("delete")){
            resp.sendRedirect("/personal/admin/service/deleteUser.jsp"); // todo :  بعد از پاک شدن کاربر صفحه سفید میشه و سی اس اس از بین میره
        }else{
            resp.getWriter().write("user id is invalid");
        }
    }
}
