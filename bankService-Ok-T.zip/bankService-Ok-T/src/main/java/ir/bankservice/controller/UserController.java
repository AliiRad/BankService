package ir.bankservice.controller;

import ir.bankservice.controller.exception.ExceptionWrapper;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.service.PersonService;
import ir.bankservice.model.service.UserService;

public class UserController {

//    This method is for Vam service ( Check zamen is valid or not )
    public String findByUserName(String username){
        try{
            String result = UserService.getUserService().selectByUsername(username).toString();
            if(result!= null){
                return "person Finded :"+result;
            }else{
                return "person doesn't Find ";
            }

        }catch (Exception e){
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String activateUser(Long id){
        try {
            if (UserService.getUserService().activateTheUser(id) != null){
                return "User Actived";
            }else{
                return UserService.getUserService().activateTheUser(id).toString();
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }




    public String delete(Long id){
        try {
            if (UserService.getUserService().selectById(id) != null){
                String answer = UserService.getUserService().delete(id).toString();
                return "delete";
            }else{
                return "User does not exist";
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public User findByUserNameAndPass(String username,String password){
        User user = null;
        try{
           user  = UserService.getUserService().selectByUsernameAndPass(username,password);
        }catch (Exception e){
            System.out.println(ExceptionWrapper.getExceptionWrapper().getMessage(e));
        }
        return user;
    }



    public String findIsActive(String username, String password){
        try {
            if (username != null && password != null){
                if (UserService.getUserService().selectActivateUser(username,password) != null){
                    return "User is Active";
                }else{
                    return "User isn't Active";
                }
            }else{
                return "username or password is null";
            }
        }catch (Exception e){
            return ExceptionWrapper.
                    getExceptionWrapper().getMessage(e);
        }
    }




}
