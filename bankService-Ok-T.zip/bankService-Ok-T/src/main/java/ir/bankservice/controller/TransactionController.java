package ir.bankservice.controller;

import ir.bankservice.controller.exception.ExceptionWrapper;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Transaction;
import ir.bankservice.model.entity.enums.Operations;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.TransactionService;

import javax.xml.stream.FactoryConfigurationError;
import java.time.LocalDateTime;

public class TransactionController {

    public String save (Operations o , String data , LocalDateTime saveDate, String cc_number){
        try {
            Card card = CardService.getCardService().selectByCcNumber(cc_number);
            Transaction transaction = new Transaction(o,data,saveDate,card);
            TransactionService.getTransactionService().insert(transaction);
            return "save";
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String delete(long id){
        try {
            if (TransactionService.getTransactionService().delete(id) != null){
                return "log deleted";
            }else{
                return "log doesn't deleted"+ TransactionService.getTransactionService().delete(id);
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String selectById(long id){
        try {
            if (TransactionService.getTransactionService().selectById(id) != null){
                return "log deleted";
            }else{
                return "log doesn't deleted"+ TransactionService.getTransactionService().selectById(id);
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String findAll(){
        try {
            if (TransactionService.getTransactionService().selectAll() != null){
                return "log finded" + TransactionService.getTransactionService().selectAll() ;
            }else{
                return "log doesn't finded"+ TransactionService.getTransactionService().selectAll();
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


}
