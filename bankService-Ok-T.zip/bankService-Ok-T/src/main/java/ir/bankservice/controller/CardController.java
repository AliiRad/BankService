package ir.bankservice.controller;

import ir.bankservice.controller.exception.ExceptionWrapper;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Transaction;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.entity.Vam;
import ir.bankservice.model.entity.enums.Operations;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.UserService;
import ir.bankservice.model.service.VamService;

import java.time.LocalDateTime;

public class CardController {

    public String variz(
            /*Card parameter*/     String first_cc, String second_cc, long amount) {
        try {
            if (first_cc.length() == 16 & second_cc.length() == 16) {
                if (CardService.getCardService().selectByCcNumber(first_cc) != null) {
                    if (CardService.getCardService().selectByCcNumber(second_cc) != null) {
                        Card first_card = CardService.getCardService().selectByCcNumber(first_cc);

                        first_card.setCredit(first_card.getCredit() - amount);
                        CardService.getCardService().update(first_card);

                        Card second_card = CardService.getCardService().selectByCcNumber(second_cc);
                        second_card.setCredit(second_card.getCredit() + amount);
                        CardService.getCardService().update(second_card);

                        String forToString = first_card.getCc_number().toString();
                        Transaction transaction = new Transaction(Operations.variz, forToString, LocalDateTime.now());

                        return "Ok Variz : " + amount;

                    } else {
                        return "شماره کارت مقصد صحیح نمیباشد";
                    }
                } else {
                    return "شماره کارت مبدا صحیح نمیباشد";
                }

            } else {
                return "داده درست وارد نشده است";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String bardasht(
            /*Card parameter*/     String cc_number, long amount) {
        try {
            if (cc_number.length() == 16) {
                Card card = CardService.getCardService().selectByCcNumber(cc_number);
                if (card.getCredit() - amount > 100 && ccIsValidate(cc_number)) {
                    card.setCredit(card.getCredit() - amount);
                    String data = CardService.getCardService().update(card).toString();
                    Transaction transaction = new Transaction(Operations.variz, data, LocalDateTime.now());
                    return "Valid Bardasht : " + amount;
                } else {
                    return "موجودی کافی نیست ";
                }
            } else {
                return "داده درست وارد نشده است";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String vam(
            String zamen,
            String cc_number, long req_amount, LocalDateTime req_date) {
        try {
            User user = UserService.getUserService().selectByUsername(zamen);
            Vam vam = new Vam(cc_number, req_amount, req_date, user);

            if (zamen.length() >= 3  && String.valueOf(req_amount).length() >=8 && CardService.getCardService().selectByCcNumber(cc_number) != null && user != null) {
                CardController cardController = new CardController();
                cardController.variz("1234567891234566", cc_number, req_amount);
                if (VamService.getVamService().insert(vam) != null) {
                    return "Ok vam : "+ req_amount + "12 Month";
                } else {
                    return "Error from vamService";
                }
            } else {
                return "شماره کارت وجود ندارد یا نام کاربری ثبت نشده است";
            }
        } catch (Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }

    }

    public String selectByCcNumberAndPassword(String cc_number,short cardPass){
        try {
            if (cc_number != null && String.valueOf(cardPass).length()==4){
                if (CardService.getCardService().selectByCcNumberAndPassword(cc_number,cardPass)!=null){
                    return "Card and cardPassword is valid";
                }else{
                    return "Card and CardPass is invalid";
                }
            }else{
                return "null value detected";
            }
        }catch (Exception e){
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


    public String addCard(String cc_number,short password , String cvv2, Long credit, LocalDateTime create_date) {
        try {
            Card card = new Card(cc_number,password, cvv2, credit);
            if ( CardService.getCardService().insert(card) != null){
                return "CardAdded";
            }else{
                return "CardNotAdded";
            }
        } catch (Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


    public boolean ccIsValidate(String cc_number) {
        try {
            if (CardService.getCardService().selectByCcNumber(cc_number) != null) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    public String getCcNumberFromUser(String username, String password) {
        try {
            String result = UserService.getUserService().getCcNumber(username, password).toString();
            if (result != null) {
                return "CardNumber Finded :" + result;
            } else {
                return "CardNumber doesn't Find ";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String findByCc(String cc_number) {
        try {
            if (CardService.getCardService().selectByCcNumber(cc_number) != null) {
                return "Card find";
            } else {
                return "Card does not exist";
            }
        } catch (Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

}
