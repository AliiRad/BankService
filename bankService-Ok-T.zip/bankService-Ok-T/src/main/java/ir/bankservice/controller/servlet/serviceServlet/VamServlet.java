package ir.bankservice.controller.servlet.serviceServlet;

import com.sun.net.httpserver.HttpsServer;
import ir.bankservice.controller.CardController;
import ir.bankservice.controller.TransactionController;
import ir.bankservice.model.entity.enums.Operations;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;


@WebServlet(urlPatterns = "/vam.do")
public class VamServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String zamen = req.getParameter("username");
        String cc_number = req.getParameter("cc_number");
        long req_amount = Long.parseLong(req.getParameter("req_amount"));
//       todo  : agar az req_date 1 month gozashte bood az heabesh soodesh ro bardasht kon
        CardController cardController = new CardController();
        if (!(req.getSession().getAttribute("username").equals(zamen))) {
            String data = cardController.vam(zamen, cc_number, req_amount, LocalDateTime.now());
            if (data.equals("Ok vam : "+ req_amount + "12 Month")) {
                req.getSession().setAttribute("vamPricePm", req_amount / 12 + (req_amount / 10));
                req.getRequestDispatcher("successPage/successVam.jsp").forward(req,resp); // todo : debug
                TransactionController trController = new TransactionController();
                trController.save(Operations.reqVam, data, LocalDateTime.now(), cc_number);
            } else {
                resp.sendRedirect("errorPages/serviceError/UnsVamReq.html");
            }
        }else{
            resp.getWriter().write("you must select valid user for zamen , you can't use your username ");
        }


    }
}

