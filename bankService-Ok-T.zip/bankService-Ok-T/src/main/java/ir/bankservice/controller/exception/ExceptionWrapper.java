package ir.bankservice.controller.exception;

import java.sql.SQLException;

public class ExceptionWrapper {
    private static ExceptionWrapper exceptionWrapper = new ExceptionWrapper();

    private ExceptionWrapper() {
    }

    public static ExceptionWrapper getExceptionWrapper() {
        return exceptionWrapper;
    }

    public String getMessage(Exception e) {
        if (e instanceof SQLException) {
            return "Error in db" + e.getMessage();
        } else if (e instanceof RuntimeException) {
            return "RunTime Error" + e.getMessage();
        } else {
            return "Unknown Error - Call admin" + e.getMessage();
        }
    }
}
