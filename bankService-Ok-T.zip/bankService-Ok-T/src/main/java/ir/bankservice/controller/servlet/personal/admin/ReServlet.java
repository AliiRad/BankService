package ir.bankservice.controller.servlet.personal.admin;

import ir.bankservice.controller.personalController.EmployeeController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/admin.rE")  // .rE : Register Employee //
public class ReServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("username");
        String family = req.getParameter("password");
        EmployeeController employeeController = new EmployeeController();
        String data = employeeController.saveEmployee(name,family);
        if (data.equals("Employee Saved")){
            resp.sendRedirect("personal/admin/admin.jsp");

        }else{
            //            401 Error occurred
            resp.sendRedirect("/errorPages/401Error.html");
        }
    }
}
