package ir.bankservice.controller.servlet.serviceServlet;

import ir.bankservice.controller.CardController;
import ir.bankservice.controller.TransactionController;
import ir.bankservice.model.entity.Transaction;
import ir.bankservice.model.entity.enums.Operations;
import ir.bankservice.model.service.TransactionService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet(urlPatterns = "/variz.do")
public class VarizServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String first_cc = req.getParameter("first_cc");
        short firstCardPass = Short.parseShort(req.getParameter("cardPass"));
        String second_cc = req.getParameter("second_cc");
        long amount = Long.parseLong(req.getParameter("amount"));
        CardController cardController = new CardController();
        if (cardController.selectByCcNumberAndPassword(first_cc, firstCardPass).equals("Card and cardPassword is valid")) {
            String data = cardController.variz(first_cc, second_cc, amount);
            if (data.equals("Ok Variz : " + amount)) {
                resp.sendRedirect("successPage/successVariz.html");
                TransactionController trController = new TransactionController();
                trController.save(Operations.variz, data, LocalDateTime.now(), first_cc);
            }
        } else {
            resp.sendRedirect("errorPages/serviceError/UnsVariz.html");
        }


    }
}
