package ir.bankservice.controller.personalController;

import ir.bankservice.controller.exception.ExceptionWrapper;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Employee;
import ir.bankservice.model.entity.Person;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.entity.enums.Role;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.EmployeeService;
import ir.bankservice.model.service.PersonService;
import ir.bankservice.model.service.UserService;

import java.time.LocalDateTime;

public class EmployeeController {

    public String saveEmployee(String name, String family) {
        try {
            if (name != null && family != null) {
                Employee employee = new Employee(name, family, Role.Employee, false);
                if (EmployeeService.getEmployeeService().insert(employee) != null) {
                    return "Employee Saved";
                } else {
                    return "Error in Save Employee";
                }

            } else {
                return "invalid Employee Register";
            }
        } catch (
                Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }

    }

//    public String registerUserFromEmployee(
//            /*Person parameter*/      String name, String family, String nc_number, String father_name
//            /*User parameter*/, String username, String password
//            /*Card parameter*/, String cc_number,short cardPassword, Long credit, String cvv2, LocalDateTime create_date) {
//        try {
//            if (name != null && family != null && nc_number != null && father_name != null &&
//                    username != null && password != null &&
//                    cc_number.length() == 16 && cvv2.length() < 5 && credit.toString().length() <= 10) {
//
//                Card card = new Card(cc_number,cardPassword, cvv2, credit, create_date);
//                User user = new User(username, password, card, false, true);
//                Person person = new Person(name, family, nc_number, father_name, user, card);
//                CardService.getCardService().insert(card);
//                UserService.getUserService().insert(user);
//                PersonService.getPersonService().insert(person);
//                return "person Saved";
//
//            } else {
//                return "داده درست وارد نشده است";
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
//        }
//    }

    public String updateUser(long id, String username, String password) {
        try {
            if (id > 0 && username != null & password != null) {
                if (UserService.getUserService().updateByUsernameAndPassword(id, username, password) != null) {
                    return "User Updated";
                } else {
                    return "Error in update user" + UserService.getUserService().updateByUsernameAndPassword(id, username, password);
                }
            } else {
                return "Invalid Update For User - Maybe Id is invalid";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }

    public String delete(Long id) {
        try {
            if (id > 0) {
                if (EmployeeService.getEmployeeService().delete(id) != null) {
                    return "employeeDeleted";
                } else {
                    return "error in deleting employee";
                }
            } else {
                return "null value detected";
            }
        } catch (Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


    //  for employee login
    public String selectByNameAndFamily(String name, String family) {
        try {
            if (EmployeeService.getEmployeeService().selectByNameAndFamily(name, family) != null) {
                return "Employee Find";
            } else {
                return "Employee does not exist";
            }
        } catch (Exception e) {
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }
}
