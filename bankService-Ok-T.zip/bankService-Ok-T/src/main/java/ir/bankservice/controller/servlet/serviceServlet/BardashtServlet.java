package ir.bankservice.controller.servlet.serviceServlet;

import ir.bankservice.controller.CardController;
import ir.bankservice.controller.TransactionController;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Transaction;
import ir.bankservice.model.entity.enums.Operations;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.TransactionService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet(urlPatterns = "/bardasht.do")
public class BardashtServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String cc_number = req.getSession().getAttribute("ccNumber").toString();
        short cardPass = Short.parseShort(req.getParameter("cardPass"));
        long amount = Long.parseLong(req.getParameter("amount"));
        System.out.println(cc_number+" "+cardPass+" "+amount);
        CardController cardController = new CardController();

        if (cardController.selectByCcNumberAndPassword(cc_number, cardPass).equals("Card and cardPassword is valid")) {
            String data = cardController.bardasht(cc_number, amount);
            if (data.equals("Valid Bardasht : " + amount)) {
                resp.sendRedirect("successPage/successBardasht.html");
                TransactionController trController = new TransactionController();
                trController.save(Operations.bardasht, data, LocalDateTime.now(), cc_number);
            } else {
                resp.sendRedirect("errorPages/serviceError/UnsBardasht.html");
            }
        } else {
            resp.getWriter().write("cardNumber and cardPass is invalid");
        }
    }


//        if (data.equals("RunTime ErrorNo result found for query [select oo from cardEntity oo where oo.cc_number=:ccNumber]")){
//            resp.sendRedirect("/errorPages/serviceError/UnsBardasht.html");
//        }else {    ///// AGAR VALID BOOD BERE BE SAFHE SUCCES
//            resp.getWriter().write("/successPage/success.html");
//        }



}
