package ir.bankservice.controller.servlet.personal.admin;

import ir.bankservice.controller.UserController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/admin.Au")  // Au : active User
public class AuServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id = Long.valueOf(req.getParameter("user_id"));
        UserController userController = new UserController();
        if (userController.activateUser(id).equals("User Actived")){
            resp.sendRedirect("personal/admin/service/activateUser.jsp");
        }else{
            resp.sendRedirect("/errorPages/401Error.html");
        }
    }
}
