package ir.bankservice.controller.servlet;

import ir.bankservice.controller.Controller;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet(urlPatterns = "/register.do")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String family = req.getParameter("family");
        String nc_number = req.getParameter("nc_number");
        String father_name = req.getParameter("father_name");

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        String cc_number = req.getParameter("cc_number");
        short cardPassword = Short.parseShort(req.getParameter("cardPass"));
        String cvv2 = req.getParameter("cvv2");
        long credit = Long.parseLong(req.getParameter("credit"));

        Controller entityController = new Controller();
        String ans = entityController.register(name, family, nc_number, father_name, username, password, cc_number,cardPassword, credit, cvv2, LocalDateTime.now());
        if (ans.equals("person Saved")) {
            resp.sendRedirect("successPage/successRegister.html");
        }else if (ans.equals("cardError")){
            resp.sendRedirect("errorPages/registerError/cardError.html");
        }else if (ans.equals("userError")){
            resp.sendRedirect("errorPages/registerError/usernameError");
        }else if (ans.equals("nationalCodeError")){
            resp.sendRedirect("errorPages/registerError/nationalCodeError.html");
        }else{
            req.getSession().setAttribute("error",ans);
            req.getRequestDispatcher("errorPages/registerError/simple.jsp").forward(req,resp);
            req.getSession().removeAttribute("error");
        }

        // todo :  برای هر خطایی که داره نمیبره به صفحه مربوطه
        //todo : fetch API

    }
}
