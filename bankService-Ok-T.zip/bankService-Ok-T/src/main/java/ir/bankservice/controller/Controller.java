package ir.bankservice.controller;

import ir.bankservice.controller.exception.ExceptionWrapper;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.entity.Person;
import ir.bankservice.model.entity.User;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.PersonService;
import ir.bankservice.model.service.UserService;

import java.time.LocalDateTime;

public class Controller {
    public String register(
            /*Person parameter*/      String name, String family, String nc_number, String father_name
            /*User parameter*/, String username, String password
            /*Card parameter*/, String cc_number,short cardpassword, Long credit, String cvv2, LocalDateTime create_date) {
        try {
            if (name != null && family != null) {
                if (nc_number != null && father_name != null) {
                    if (username != null  && password != null) {
                        if (cc_number.length() == 16 && String.valueOf(cardpassword).length() == 4 &&cvv2.length() < 5 && credit.toString().length() >= 7  ) {
                            Card card = new Card(cc_number,cardpassword, cvv2, credit);
//                            CardService.getCardService().insert(card);
                            Person person = new Person(name, family, nc_number, father_name, card);
//                            PersonService.getPersonService().insert(person);
                            User user = new User(username, password,person, false, false  );
                            UserService.getUserService().insert(user);
                            return "person Saved";
                        }else{
                            return "cardError";
                        }
                    }else{
                        return "userError";
                    }
                } else {
                    return "nationalCodeError";
                }
            } else {
                return "nameAndFamily is null";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return ExceptionWrapper.getExceptionWrapper().getMessage(e);
        }
    }


}
