package ir.bankservice.controller.servlet.personal.admin;

import ir.bankservice.controller.personalController.EmployeeController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/admin.De") // De = delete Employee (Logical)
public class DeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id = Long.valueOf(req.getParameter("employee_id"));
        EmployeeController employeeController = new EmployeeController();
        if (employeeController.delete(id).equals("employeeDeleted")){
            resp.sendRedirect("/personal/admin/admin.jsp");
        }else{
            resp.sendError(401);
        }
    }
}
