package ir.bankservice.controller.servlet.personal;

import ir.bankservice.controller.personalController.EmployeeController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/personalLogin.do")
public class PersonalLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        EmployeeController employeeController = new EmployeeController();
        if (username.equals("admin") && password.equals("admin")) {
            req.getSession().setAttribute("AdminRole", "admin");
            req.getRequestDispatcher("personal/admin/admin.jsp").forward(req, resp);
        } else if (employeeController.selectByNameAndFamily(username, password).equals("Employee Find")) {
            req.getSession().setAttribute("EmployeeRole", "employee");
            req.getRequestDispatcher("personal/employee/employee.jsp").forward(req, resp);
        }else if (username.equals("privacy") && password.equals("privacy")){
            req.getSession().setAttribute("privacy",true);
            req.getRequestDispatcher("personal/admin/service/addCard.jsp").forward(req,resp);
        }else {
            resp.sendRedirect("/errorPages/UnsLogin.html");
        }
    }
}
