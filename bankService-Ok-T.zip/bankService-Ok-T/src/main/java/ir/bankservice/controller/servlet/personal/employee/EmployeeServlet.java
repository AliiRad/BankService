package ir.bankservice.controller.servlet.personal.employee;

import ir.bankservice.controller.personalController.EmployeeController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDateTime;

@WebServlet(urlPatterns = "/employee.delete")
public class EmployeeServlet extends HttpServlet {
//   long id, String username, String password,String cc_number,String cvv2,Long credit,LocalDateTime create_date
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Long id = Long.valueOf(req.getParameter("id"));

        EmployeeController employeeController = new EmployeeController();
        if (employeeController.delete(id).equals("employeeDeleted")){
            resp.sendRedirect("personal/employee/employee.jsp");
        }else{
//            401 Error occurred
            resp.sendRedirect("/errorPages/401Error.html");
        }

    }
}
