//package ir.bankservice.controller.filter;
//
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.annotation.WebFilter;
//import jakarta.servlet.http.HttpFilter;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//import java.io.IOException;
//
//@WebFilter(urlPatterns = "/personal/*")
//public class SecurityFilter extends HttpFilter {
//    @Override
//    protected void doFilter(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {
//        res.sendRedirect("/errorPages/invalidAccess.html"); // todo : mire be safhe error.html vali bayad bere be safhe invalidAccess.html
//        System.out.println("Warning !!  \n  Invalid Access to personal Page ");
//        doFilter(req,res,chain);
//    }
//}
