package ir.bankservice.controller.servlet;

import ir.bankservice.controller.UserController;
import ir.bankservice.controller.personalController.EmployeeController;
import ir.bankservice.model.entity.User;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(urlPatterns = "/login.do")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        UserController userController = new UserController();
        User user = userController.findByUserNameAndPass(username, password);
        if (user != null) {
            if (userController.findIsActive(username, password).equals("User is Active")) {
                req.getSession().setAttribute("validator", userController.findByUserNameAndPass(username, password));
                req.getSession().setAttribute("username", username);
                req.getSession().setAttribute("password", password);
                req.getSession().setAttribute("ccNumber", user.getPerson().getCard().getCc_number());
                String nextHTML = "/dashboard.jsp";
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(nextHTML);

                dispatcher.forward(req, resp);
            } else {
                resp.sendRedirect("errorPages/deActiveUser.html");


            }
        } else {
            resp.sendRedirect("/errorPages/UnsLogin.html");
        }

    }

}

