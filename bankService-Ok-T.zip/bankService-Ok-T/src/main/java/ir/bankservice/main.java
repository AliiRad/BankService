package ir.bankservice;

import ir.bankservice.controller.CardController;
import ir.bankservice.controller.Controller;
import ir.bankservice.controller.UserController;
import ir.bankservice.controller.personalController.EmployeeController;
import ir.bankservice.model.entity.Card;
import ir.bankservice.model.service.CardService;
import ir.bankservice.model.service.UserService;

import java.time.LocalDateTime;

public class main {
    public static void main(String[] args) throws Exception {




        Controller controller = new Controller();
//        System.out.println(controller.register("علی", "گلمنظر راد", "0151451963", "فرامرز", "mohsen", "reza123", "5894631578120884", (short) 2007, 100000000L, "1354", LocalDateTime.now()));
//        System.out.println(CardService.getCardService().selectByCcNumberAndPassword("5894631578120883", (short) 2007));

//        System.out.println(CardService.getCardService().selectByCcNumber("5894631578001245").getId());

//        System.out.println(CardService.getCardService().selectByCcNumber("5894631578120882"));

//        Card card = new Card("5894631578120883","1234",1000000L, LocalDateTime.now());
//
//        System.out.println(UserService.getUserService().updateByUsernameAndPassword(1, "abbas", "ghoalmi"));
//        UserController userController = new UserController();
//        System.out.println(userController.findIsActive("ali", "ali123"));
//        CardController cardController = new CardController();
//        System.out.println(cardController.bardasht("5894631578120883", 1000L));

//        System.out.println(UserService.getUserService().selectActivateUser("ali", "ali123"));

//        UserController controller = new UserController();
//        System.out.println(controller.findIsActive("ali", "ali123"));
//        EmployeeController employeeController = new EmployeeController();
//        System.out.println();
//        System.out.println(UserService.getUserService().updateByUsernameAndPassword(7, "alki", "alaki"));
//        System.out.println(employeeController.updateUser(7L, "ali", "abbasi"));
//        System.out.println(CardService.getCardService().selectById(5L));
//        System.out.println(employeeController.save("ali", "rad", false));
//        User user = new User("ali","ali123");
//        System.out.println("User Save : "+UserService.getUserService().insert(user));
//        System.out.println("Update User from Employee  : "+employeeController.updateUser(8,"agssdfli","gsdfsdfsgsdf"));


//        Controller controller = new Controller();
//        System.out.println(controller.register("علی", "راد", "0151451771", "فرامرز", "ali", "ali123", "5894631578120883", 1000000L, "1234", LocalDateTime.now()));
//        Card card = new Card("5894631578120883","1234",1000000L,LocalDateTime.now());
//        System.out.println(CardService.getCardService().insert(card));
//        User user = new User("ali","rad",false,card);
//        UserController userController = new UserController();
//        userController.
//        System.out.println(UserService.getUserService().insert(user));
//        System.out.println(UserService.getUserService().delete(1L));
//        System.out.println(UserService.getUserService().selectAllDeleted());
//        System.out.println(controller.register("علی", "راد", "0151451771", "فرتسی", "ali", "ali123", "5894631578120552", 1000000L, "1234", LocalDateTime.now()));

//        CardController cardController = new CardController();
//
//        UserController userController = new UserController();

//        System.out.println(userController.getCcNumber("ali", "ali123"));

//        LocalDateTime localDateTime = LocalDateTime.now();


//        Card card = new Card("5894631578120883","1234",1000L,LocalDateTime.now());
//        User user = new User("ali","ali123",false,card);  in main it works
//        System.out.println(user.getCard().getCc_number());




//        Controller controller = new Controller();
//        System.out.println(controller.register("ادمین", "ادمین", "0151451771", "نامپدر", "admin", "admin", "1234567891234566", 9000000000000000000L, LocalDateTime.of(2000, Month.APRIL, 1, 1, 1)));
//        System.out.println(cardController.vam("abbas", "5894631578120883", 1000000L, LocalDateTime.now()));
//        System.out.println(cardController.ccIsValidate("5894631578540883"));

//Person person = new Person();

//        UserController userController = new UserController();    //Done
//        System.out.println(userController.findByUserNameAndPass("ali", "ali123"));

//        Card card = CardService.getCardService().selectByCcNumber("5894632254114588");  //  Done
//
//
//        if (card != null){
//            System.out.println("card finded");
//        }else{
//            System.out.println("card isn't finded");
//        }




//        User user = UserService.getUserService().selectByUsername("ali");

//        if (user != null){     Done All if else about user
//            System.out.println("user isn't null");
//        }else{
//            System.out.println("user is null");
//        }



    }
}
