// function deleteEmployee(id){
//     fetch("http://localhost/admin.De"), {
//         method: 'delete', // Specify the HTTP method
//         body: new FormData(document.querySelector('form')) // Collect form data })
//             .then(response => response.json()) // Read response as text
//             .then(data => alert(data)) // Alert the response
//
//     }
// }

function deleteEmployee(id) {
    fetch("http://localhost/admin.De", {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json'
        },
        body: Json.stringify({
            id: id
        })
    }).then(res => {
        return res.json()
    })
        .then(data => alert(data))
        .catch(error => alert('Error delete employee - javascript fetch Line24'))

}